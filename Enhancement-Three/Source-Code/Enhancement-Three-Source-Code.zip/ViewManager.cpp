///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp> 
#include <glm/gtc/matrix_transform.hpp>

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();

	// default camera view parameters
	g_pCamera->Position = glm::vec3(0.0f, 7.0f, 22.0f);
	g_pCamera->Yaw = -90.0f;
	g_pCamera->Pitch = -15.0f;
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 60.0f;

	// force update of Front/Right/Up vectors
	g_pCamera->ProcessMouseMovement(0.0f, 0.0f);
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events
	// Lock/hide the cursor so mouse movement feels like a true camera look control
	// (This makes the mouse control smoother for first-person navigation.)
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// Scroll wheel adjusts camera travel speed (fast vs precision movement)
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// First frame safeguard: prevents the camera from "jumping" on the initial mouse move
	if (gFirstMouse)
	{
		gLastX = (float)xMousePos;
		gLastY = (float)yMousePos;
		gFirstMouse = false;
	}

	// Calculate offset since last frame
	float xOffset = (float)xMousePos - gLastX;
	float yOffset = gLastY - (float)yMousePos; // reversed: y grows downward on screen

	gLastX = (float)xMousePos;
	gLastY = (float)yMousePos;

	// Apply the offsets to rotate the camera (yaw/pitch)
	if (g_pCamera != nullptr)
	{
		g_pCamera->ProcessMouseMovement(xOffset, yOffset);
	}
}

void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	if (g_pCamera != nullptr)
	{
		// LearnOpenGL camera class uses scroll to change MovementSpeed in this project
		g_pCamera->ProcessMouseScroll((float)yOffset);
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// Always allow ESC to exit quickly during testing
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// ------------------------------------------
	// Camera translation (WASD + QE)
	// ------------------------------------------
	// Uses deltaTime so movement stays consistent across different frame rates.
	if (g_pCamera != nullptr)
	{
		if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
			g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
		if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
			g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
		if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
			g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
		if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
			g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);

		// Vertical movement (up/down)
		if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
			g_pCamera->ProcessKeyboard(UP, gDeltaTime);
		if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
			g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	}

	// ------------------------------------------
	// Projection toggle (O = Ortho, P = Perspective)
	// ------------------------------------------
	// Simple key taps: to avoid rapid flipping, we can use a basic latch.
	static bool oWasDown = false;
	static bool pWasDown = false;

	bool oDown = (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS);
	bool pDown = (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS);

	if (oDown && !oWasDown)
	{
		SetOrthographic(true);

		// For ortho view, point the camera directly at the object area.
		// (This matches the milestone expectation of a straight-on �2D style� view.)
		g_pCamera->Position = glm::vec3(0.0f, 3.0f, 12.0f);
		g_pCamera->Yaw = -90.0f;
		g_pCamera->Pitch = -10.0f;

		// Force camera vectors to update right now (so view changes instantly)
		g_pCamera->ProcessMouseMovement(0.0f, 0.0f);
	}

	if (pDown && !pWasDown)
	{
		SetOrthographic(false);

		// Return to a more typical perspective camera angle for navigation.
		g_pCamera->Position = glm::vec3(0.0f, 6.0f, 18.0f);
		g_pCamera->Yaw = -90.0f;
		g_pCamera->Pitch = -15.0f;

		// Force camera vectors to update right now
		g_pCamera->ProcessMouseMovement(0.0f, 0.0f);
	}

	oWasDown = oDown;
	pWasDown = pDown;
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the 
	// event queue
	ProcessKeyboardEvents();

	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	// define the current projection matrix
	if (!IsOrthographic())
	{
		// Perspective (3D) view
		projection = glm::perspective(glm::radians(g_pCamera->Zoom),
			(GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT,
			0.1f, 100.0f);
	}
	else
	{
		// Orthographic (2D-style) view
		// Keep the frustum tight so the object fills the view more like a �flat� display.
		float aspect = (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT;
		float orthoSize = 6.0f;

		projection = glm::ortho(-orthoSize * aspect, orthoSize * aspect,
			-orthoSize, orthoSize,
			0.1f, 100.0f);
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}