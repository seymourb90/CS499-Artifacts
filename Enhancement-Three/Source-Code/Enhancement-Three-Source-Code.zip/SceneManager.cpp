﻿///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <fstream>
#include <sstream>

#include "ViewManager.h"

// Use the existing ViewManager created in main.cpp
extern ViewManager* g_ViewManager;

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	m_loadedTextures = 0;   
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// Flip so textures match the UV orientation used in this project
	stbi_set_flip_vertically_on_load(true);

	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (m_pShaderManager != NULL)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);
		m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(1.0f));

		int slot = FindTextureSlot(textureTag);

		if (slot < 0)
		{
			std::cout << "ERROR: Texture tag not found: " << textureTag << std::endl;
			slot = 0;
		}

		m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (m_objectMaterials.empty() || m_pShaderManager == NULL)
		return;

	OBJECT_MATERIAL material;
	if (FindMaterial(materialTag, material))
	{
		m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
		m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
		m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
		m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
		m_pShaderManager->setFloatValue("material.shininess", material.shininess);
	}
}
/***********************************************************
 *  SetShaderLighting()
 *
 *  This method controls whether lighting effects are applied
 *  to objects during rendering.
 ***********************************************************/
void SceneManager::SetShaderLighting(bool bUseLighting)
{
	if (m_pShaderManager != NULL)
	{
		m_pShaderManager->setIntValue(g_UseLightingName, bUseLighting);
	}
}

void SceneManager::UseWhiteTextureColor()
{
	if (m_pShaderManager != NULL)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);
		m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(1.0f));
	}
}


bool SceneManager::LoadSceneObjectsFromCSV(const std::string& filePath)
{
	m_sceneObjects.clear();

	std::ifstream file(filePath);

	if (!file.is_open())
	{
		std::cout << "ERROR: Could not open scene object CSV file: " << filePath << std::endl;
		return false;
	}

	std::string line;

	// Skip the header row
	std::getline(file, line);

	while (std::getline(file, line))
	{
		if (line.empty())
		{
			continue;
		}

		std::stringstream ss(line);
		std::string value;
		SceneObject object;

		std::getline(ss, object.name, ',');
		std::getline(ss, object.objectType, ',');
		std::getline(ss, object.textureTag, ',');

		std::getline(ss, value, ',');
		object.scale.x = std::stof(value);

		std::getline(ss, value, ',');
		object.scale.y = std::stof(value);

		std::getline(ss, value, ',');
		object.scale.z = std::stof(value);

		std::getline(ss, value, ',');
		object.rotation.x = std::stof(value);

		std::getline(ss, value, ',');
		object.rotation.y = std::stof(value);

		std::getline(ss, value, ',');
		object.rotation.z = std::stof(value);

		std::getline(ss, value, ',');
		object.position.x = std::stof(value);

		std::getline(ss, value, ',');
		object.position.y = std::stof(value);

		std::getline(ss, value, ',');
		object.position.z = std::stof(value);

		std::getline(ss, value, ',');
		object.uvScale.x = std::stof(value);

		std::getline(ss, value, ',');
		object.uvScale.y = std::stof(value);

		m_sceneObjects.push_back(object);
	}

	std::cout << "INFO: Loaded " << m_sceneObjects.size() << " scene objects from CSV." << std::endl;

	return true;
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadBoxMesh();

	bool ok = true;
	ok &= CreateGLTexture("../../Utilities/textures/black_ceramic.jpg", "mug");
	ok &= CreateGLTexture("../../Utilities/textures/ceramic_handle.jpg", "mug_handle");
	ok &= CreateGLTexture("../../Utilities/textures/rusticwood.jpg", "table");
	ok &= CreateGLTexture("../../Utilities/textures/coffee.jpg", "coffee");

	ok &= CreateGLTexture("../../Utilities/textures/stainless.jpg", "stainless");
	ok &= CreateGLTexture("../../Utilities/textures/stainless_end.jpg", "stainless_end");
	ok &= CreateGLTexture("../../Utilities/textures/circular-brushed-gold-texture.jpg", "coin_gold");

	if (!ok)
		std::cout << "ERROR: One or more textures failed to load. Check file paths.\n";

	BindGLTextures();

	if (!LoadSceneObjectsFromCSV("data/sceneObjects.csv"))
	{
		std::cout << "ERROR: Scene object data could not be loaded." << std::endl;
	}
}

void SceneManager::SetupSceneLighting()
{
	SetShaderLighting(true);

	// Directional light
	m_pShaderManager->setVec3Value("dirLight.direction", glm::vec3(-0.2f, -1.0f, -0.15f));
	m_pShaderManager->setVec3Value("dirLight.ambient", glm::vec3(0.12f));
	m_pShaderManager->setVec3Value("dirLight.diffuse", glm::vec3(0.55f));
	m_pShaderManager->setVec3Value("dirLight.specular", glm::vec3(0.18f));

	// Point light
	m_pShaderManager->setVec3Value("pointLight.position", glm::vec3(-2.5f, 5.5f, 6.5f));
	m_pShaderManager->setVec3Value("pointLight.ambient", glm::vec3(0.02f));
	m_pShaderManager->setVec3Value("pointLight.diffuse", glm::vec3(1.00f, 0.88f, 0.72f));
	m_pShaderManager->setVec3Value("pointLight.specular", glm::vec3(1.00f));

	// Attenuation
	m_pShaderManager->setFloatValue("pointLight.constant", 1.0f);
	m_pShaderManager->setFloatValue("pointLight.linear", 0.022f);
	m_pShaderManager->setFloatValue("pointLight.quadratic", 0.0019f);
}

void SceneManager::RenderTable()
{
    glm::vec3 scaleXYZ;
    glm::vec3 positionXYZ;

    scaleXYZ = glm::vec3(18.0f, 1.0f, 12.0f);

    positionXYZ = glm::vec3(0.0f, 0.0f, 3.0f);

    SetTransformations(
        scaleXYZ,
        0.0f,
        0.0f,
        0.0f,
        positionXYZ);

    SetShaderColor(1, 1, 1, 1);

    if (g_ViewManager == nullptr || !g_ViewManager->IsOrthographic())
    {
        m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(1.0f));
        m_pShaderManager->setFloatValue("material.ambientStrength", 0.30f);
        m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f));
        m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.20f));
        m_pShaderManager->setFloatValue("material.shininess", 16.0f);

        SetShaderTexture("table");
        UseWhiteTextureColor();
        SetTextureUVScale(4.0f, 4.0f);

        m_basicMeshes->DrawPlaneMesh();
    }
}

void SceneManager::RenderMug()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	const float zPush = 5.5f;

	// Mug object : cylinder body + torus handle

	// -----------------------------
	// Part A: Mug Body (Cylinder)
	// -----------------------------
	// Mug body
	scaleXYZ = glm::vec3(1.25f, 2.0f, 1.25f); // width, height, depth
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-2.0f, 0.0f, 1.8f + zPush);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Mug material
	m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(1.0f, 1.0f, 1.0f));
	m_pShaderManager->setFloatValue("material.ambientStrength", 0.25f);
	m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f, 1.0f, 1.0f));
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.25f, 0.25f, 0.25f));
	m_pShaderManager->setFloatValue("material.shininess", 16.0f);

	// Mug body
	SetShaderTexture("mug");
	UseWhiteTextureColor();
	SetTextureUVScale(3.0f, 1.5f);
	m_basicMeshes->DrawCylinderMesh();

	// ------------------------------------------------------------
	// Mug rim + coffee surface
	// ------------------------------------------------------------

	float mugTopY = 0.0f + 2.0f; // positionY + scaleY

	// Rim
	scaleXYZ = glm::vec3(1.27f, 0.015f, 1.27f);
	positionXYZ = glm::vec3(-2.0f, mugTopY - 0.0075f, 1.8f + zPush);
	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderColor(0.95f, 0.95f, 0.95f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();


	// Coffee surface
	scaleXYZ = glm::vec3(1.18f, 0.03f, 1.18f);
	positionXYZ = glm::vec3(-2.0f, mugTopY - 0.02f, 1.8f + zPush);
	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);

	SetShaderTexture("coffee");
	UseWhiteTextureColor();
	SetTextureUVScale(1.0f, 1.0f);

	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.05f));
	m_pShaderManager->setFloatValue("material.shininess", 4.0f);

	m_basicMeshes->DrawCylinderMesh();

	// -----------------------------
	// Part B: Mug Handle (Torus)
	// -----------------------------
	scaleXYZ = glm::vec3(0.55f, 0.55f, 0.25f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	positionXYZ = glm::vec3(-0.7f, 1.05f, 1.8f + zPush);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("mug_handle");
	UseWhiteTextureColor();
	SetTextureUVScale(2.0f, 2.0f);

	m_basicMeshes->DrawTorusMesh();

	// Reset UV scaling back to normal for anything drawn after the mug
	SetTextureUVScale(1.0f, 1.0f);
}

void SceneManager::RenderFlashlight()
{
	const float zPush = 5.5f;

	// -----------------------------
	// Flashlight (body + caps aligned using axis vector)
	// -----------------------------
	const float zF = 2.2f + zPush;
	glm::vec3 flashPos = glm::vec3(3.2f, 0.35f, zF);

	glm::vec3 bodyScale = glm::vec3(0.35f, 2.4f, 0.35f);
	glm::vec3 capScaleF = glm::vec3(0.40f, 0.18f, 0.40f);
	glm::vec3 capScaleB = glm::vec3(0.38f, 0.18f, 0.38f);

	float rx = 90.0f;
	float ry = 0.0f;
	float rz = 25.0f;

	// Draw body
	SetTransformations(bodyScale, rx, ry, rz, flashPos);
	SetShaderTexture("stainless");
	UseWhiteTextureColor();
	m_basicMeshes->DrawCylinderMesh();

	glm::mat4 R(1.0f);
	R = glm::rotate(glm::radians(rx), glm::vec3(1, 0, 0)) *
		glm::rotate(glm::radians(ry), glm::vec3(0, 1, 0)) *
		glm::rotate(glm::radians(rz), glm::vec3(0, 0, 1));

	glm::vec3 axis = glm::normalize(glm::vec3(R * glm::vec4(0, 1, 0, 0)));

	float bodyHalf = 0.5f * bodyScale.y;
	float capHalfF = 0.5f * capScaleF.y;
	float capHalfB = 0.5f * capScaleB.y;
	float gap = -1.2f;

	glm::vec3 frontPos = flashPos + axis * (bodyHalf + capHalfF + gap);
	glm::vec3 backPos = flashPos - axis * (bodyHalf + capHalfB + gap);

	// Front cap
	SetShaderTexture("stainless_end");
	UseWhiteTextureColor();
	SetTransformations(capScaleF, rx, ry, rz, frontPos);
	m_basicMeshes->DrawCylinderMesh();

	// Back cap
	SetTransformations(capScaleB, rx, ry, rz, backPos);
	m_basicMeshes->DrawCylinderMesh();
}

void SceneManager::RenderDogTagChain()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;
	const float zPush = 5.5f;

	// -----------------------------
	// Dog Tag Chain (torus links)
	// -----------------------------
	SetShaderTexture("stainless_end");
	UseWhiteTextureColor();
	m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(1.0f));
	m_pShaderManager->setFloatValue("material.ambientStrength", 0.20f);
	m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f));
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
	m_pShaderManager->setFloatValue("material.shininess", 96.0f);

	glm::vec3 chainStart(-3.2f, 0.03f, 4.0f + zPush);
	glm::vec3 chainEnd(-0.4f, 0.03f, 4.4f + zPush);

	for (int i = 0; i < 18; i++)
	{
		float t = (float)i / 17.0f;

		float x = chainStart.x + (chainEnd.x - chainStart.x) * t;
		float z = chainStart.z + (chainEnd.z - chainStart.z) * t;

		// droop in the middle of the chain
		float droop = 0.15f * sinf(t * 3.1415f);

		positionXYZ = glm::vec3(x, 0.03f, z - droop);
		scaleXYZ = glm::vec3(0.10f, 0.10f, 0.05f);

		SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
		m_basicMeshes->DrawTorusMesh();
	}
}

void SceneManager::RenderSceneObject(const SceneObject& object)
{
	SetTransformations(
		object.scale,
		object.rotation.x,
		object.rotation.y,
		object.rotation.z,
		object.position);

	SetShaderTexture(object.textureTag);

	UseWhiteTextureColor();

	SetTextureUVScale(
		object.uvScale.x,
		object.uvScale.y);

	if (object.textureTag == "coin_gold")
	{
		m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(1.0f));
		m_pShaderManager->setFloatValue("material.ambientStrength", 0.25f);
		m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f));
		m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
		m_pShaderManager->setFloatValue("material.shininess", 128.0f);
	}

	if (object.textureTag == "stainless")
	{
		m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(1.0f));
		m_pShaderManager->setFloatValue("material.ambientStrength", 0.20f);
		m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f));
		m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
		m_pShaderManager->setFloatValue("material.shininess", 96.0f);
	}

	if (object.objectType == "cylinder")
	{
		m_basicMeshes->DrawCylinderMesh();
	}
	else if (object.objectType == "box")
	{
		m_basicMeshes->DrawBoxMesh();
	}
	else if (object.objectType == "torus")
	{
		m_basicMeshes->DrawTorusMesh();
	}
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	SetupSceneLighting();
	RenderTable();
	RenderMug();
	RenderFlashlight();
	RenderDogTagChain();

	for (const SceneObject& object : m_sceneObjects)
	{
		RenderSceneObject(object);
	}
}
